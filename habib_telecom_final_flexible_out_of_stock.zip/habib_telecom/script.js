
let stock = JSON.parse(localStorage.getItem("stock")) || [];
let totalSales = parseFloat(localStorage.getItem("totalSales")) || 0;
let totalExpenses = parseFloat(localStorage.getItem("totalExpenses")) || 0;
let expenseLog = JSON.parse(localStorage.getItem("expenseLog")) || [];
let salesLog = JSON.parse(localStorage.getItem("salesLog")) || [];

function saveData() {
  localStorage.setItem("stock", JSON.stringify(stock));
  localStorage.setItem("totalSales", totalSales);
  localStorage.setItem("totalExpenses", totalExpenses);
  localStorage.setItem("expenseLog", JSON.stringify(expenseLog));
  localStorage.setItem("salesLog", JSON.stringify(salesLog));
}

function addProduct() {
  const name = document.getElementById('pName').value.trim();
  const price = parseFloat(document.getElementById('pPrice').value);
  const qty = parseInt(document.getElementById('pQty').value);

  if (!name || isNaN(price) || isNaN(qty)) {
    alert("Enter valid product data");
    return;
  }

  stock.push({ name, price, qty });
  saveData();

  document.getElementById('pName').value = '';
  document.getElementById('pPrice').value = '';
  document.getElementById('pQty').value = '';
}

function recordSale() {
  const name = document.getElementById('sName').value.trim();
  const qty = parseInt(document.getElementById('sQty').value);
  const date = document.getElementById('sDate').value || new Date().toISOString().split('T')[0];

  const entry = stock.find(p => p.name === name);
  if (!entry) {
    salesLog.push(`${date} - Tried to sell ${qty} x ${name} → ❌ Not in stock`);
  } else if (entry.qty < qty) {
    salesLog.push(`${date} - Tried to sell ${qty} x ${name} → ❌ Only ${entry.qty} in stock`);
  } else {
    entry.qty -= qty;
    const saleAmount = entry.price * qty;
    totalSales += saleAmount;
    salesLog.push(`${date} - Sold ${qty} x ${name} @ $${entry.price} = $${saleAmount}`);
  }

  saveData();
  updateProfit();
  updateSalesLog();

  document.getElementById('sName').value = '';
  document.getElementById('sQty').value = '';
  document.getElementById('sDate').value = '';
}

function addExpense() {
  const amount = parseFloat(document.getElementById('eAmount').value);
  const date = document.getElementById('eDate').value || new Date().toISOString().split('T')[0];
  if (isNaN(amount)) {
    alert("Enter valid expense");
    return;
  }
  totalExpenses += amount;
  expenseLog.push(`${date} - Expense: $${amount}`);

  saveData();
  updateProfit();
  updateExpenseLog();

  document.getElementById('eAmount').value = '';
  document.getElementById('eDate').value = '';
}

function searchStock() {
  const name = document.getElementById('searchName').value.trim();
  const filtered = stock.filter(p => p.name.toLowerCase() === name.toLowerCase());
  const table = document.getElementById('stockTable');
  const section = document.getElementById('stockSection');

  table.innerHTML = '<tr><th>Product</th><th>Price</th><th>Quantity</th></tr>';
  if (filtered.length === 0) {
    table.innerHTML += `<tr><td colspan="3">No stock found for "${name}"</td></tr>`;
  } else {
    filtered.forEach(entry => {
      table.innerHTML += `<tr><td>${entry.name}</td><td>$${entry.price}</td><td>${entry.qty}</td></tr>`;
    });
  }

  section.style.display = 'block';
}

function showExpenses() {
  document.getElementById('expenseSection').style.display = 'block';
  updateExpenseLog();
}

function searchSalesByDate() {
  const date = document.getElementById('searchSalesDate').value;
  if (!date) return;

  const log = document.getElementById('salesLog');
  log.innerHTML = '';

  const filtered = salesLog.filter(entry => entry.startsWith(date));
  if (filtered.length === 0) {
    log.innerHTML = `<li>No sales found for ${date}</li>`;
  } else {
    filtered.forEach(item => {
      const li = document.createElement('li');
      li.textContent = item;
      log.appendChild(li);
    });
  }

  document.getElementById('salesSection').style.display = 'block';
}

function updateProfit() {
  document.getElementById('totalSales').textContent = totalSales.toFixed(2);
  document.getElementById('totalExpenses').textContent = totalExpenses.toFixed(2);
  document.getElementById('netProfit').textContent = (totalSales - totalExpenses).toFixed(2);
}

function updateExpenseLog() {
  const log = document.getElementById('expenseLog');
  log.innerHTML = '';
  expenseLog.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    log.appendChild(li);
  });
}

function updateSalesLog() {
  const log = document.getElementById('salesLog');
  log.innerHTML = '';
  salesLog.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    log.appendChild(li);
  });
}

document.addEventListener("DOMContentLoaded", function() {
  updateProfit();
  updateExpenseLog();
  updateSalesLog();
});
